#!/usr/bin/env python
# https://www.geeksforgeeks.org/how-to-add-two-hexadecimal-numbers/

# Python equivalent of above code
 
# Create maps to convert hexadecimal values to decimal and vice versa
hex_value_of_dec = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4,
 '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'A':
 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15}
dec_value_of_hex = {0: '0', 1: '1', 2: '2', 3: '3', 4: '4',
 5: '5', 6: '6', 7: '7', 8: '8', 9: '9',
 10: 'A', 11: 'B', 12: 'C', 13: 'D', 14: 'E', 15: 'F'}
 
# Function to add the two hexadecimal numbers
def Add_Hex(a, b):
    # Check if length of string first is
    # greater than or equal to string second
    if len(a) < len(b):
        a, b = b, a
    # Store length of both strings
    l1, l2 = len(a), len(b)
    ans = ""
    # Initialize carry as zero
    carry = 0
    i, j = l1 - 1, l2 - 1
    # Traverse till second string
    # get traversal completely
    while j >= 0:
        # Decimal value of element at a[i]
        # Decimal value of element at b[i]
        sum = hex_value_of_dec[a[i]] + hex_value_of_dec[b[j]] + carry
        # Hexadecimal value of sum%16
        # to get addition bit
        addition_bit = dec_value_of_hex[sum % 16]
        # Add addition_bit to answer
        ans += addition_bit
        # Update carry
        carry = sum // 16
        i, j = i - 1, j - 1
    # Traverse remaining element
    # of string a
    while i >= 0:
        # Decimal value of element
        # at a[i]
        sum = hex_value_of_dec[a[i]] + carry
        # Hexadecimal value of sum%16
        # to get addition bit
        addition_bit = dec_value_of_hex[sum % 16]
        # Add addition_bit to answer
        ans += addition_bit
        # Update carry
        carry = sum // 16
        i -= 1
    # Check if still carry remains
    if carry:
        ans += dec_value_of_hex[carry]
    # Reverse the final string
    # for desired output
    ans = ans[::-1]
    # Return the answer
    return ans
 
# Driver Code
if __name__ == '__main__':
    # Initialize the hexadecimal values
    str1, str2 = "1", "F"
    # Function call
    print(Add_Hex(str1, str2))# Driver Code

