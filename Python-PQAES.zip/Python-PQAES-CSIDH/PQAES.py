#!/usr/bin/env python
# -*- coding: utf-8 -*-

# ---------------------------------------------------
# Copyright (c) 2023 RAKOTONDRAMANANA Radiarisainana Sitraka. All Rights Reserved.
# email : radiarisainanasitraka@yahoo.fr
# PQAES.py
# ---------------------------------------------------

import sys
import os.path
from ProgressBar import ProgressBar
from AES_base import sbox, isbox, gfp2, gfp3, gfp9, gfp11, gfp13, gfp14, Rcon
import binascii

if sys.version_info[0] == 3:
    raw_input = input



import hashlib
import hmac
from functools import reduce

hash_len_256 = 32
hash_len_512 = 256


#https://handwiki.org/wiki/HKDF
#sha3_256, sha256, blake2s
###########################################  SHA 256  ##########################################
def hmac_sha256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha256).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_sha256(salt, ikm)

def hkdf_expand_sha256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = 0
    while len(okm) < length:
        i += 1
        t = hmac_sha256(prk, t + info + bytes([i]))
        okm += t
    return okm[:length]

def hkdf_sha256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha256(salt, ikm)
    return hkdf_expand_sha256(prk, info, length)

###########################################  SHA 512  ##########################################

def hmac_sha512(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha512).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha512(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_512)
    return hmac_sha512(salt, ikm)

def hkdf_expand_sha512(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = 0
    while len(okm) < length:
        i += 1
        t = hmac_sha512(prk, t + info + bytes([i]))
        okm += t
    return okm[:length]

def hkdf_sha512(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha512(salt, ikm)
    return hkdf_expand_sha512(prk, info, length)


###########################################  SHA3 256  ##########################################

def hmac_sha3_256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha3_256).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha3_256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_sha3_256(salt, ikm)

def hkdf_expand_sha3_256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = 0
    while len(okm) < length:
        i += 1
        t = hmac_sha3_256(prk, t + info + bytes([i]))
        okm += t
    return okm[:length]

def hkdf_sha3_256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha3_256(salt, ikm)
    return hkdf_expand_sha3_256(prk, info, length)

###########################################  SHA3 512  ##########################################

def hmac_sha3_512(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha3_512).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha3_512(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_512)
    return hmac_sha3_512(salt, ikm)

def hkdf_expand_sha3_512(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = 0
    while len(okm) < length:
        i += 1
        t = hmac_sha3_512(prk, t + info + bytes([i]))
        okm += t
    return okm[:length]

def hkdf_sha3_512(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha3_512(salt, ikm)
    return hkdf_expand_sha3_512(prk, info, length)

###########################################  BLAKE 256  ##########################################

def hmac_blake256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.blake2b).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_blake256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_blake256(salt, ikm)

def hkdf_expand_blake256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = 0
    while len(okm) < length:
        i += 1
        t = hmac_blake256(prk, t + info + bytes([i]))
        okm += t
    return okm[:length]


def hkdf_blake256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_blake256(salt, ikm)
    return hkdf_expand_blake256(prk, info, length)

###########################################  PQAES EXPAND  ##########################################

def pqaes_expand(okm) :
    s = okm.hex()
    #print("len "+str(len(okm.hex())))
    n=2
    s2= [s[i:i+n] for i in range(0, len(s), 2)]

    #print(s2)
    #print("len "+str(len(s2)))
    decimal = []
    for hex_to_be_trans in s2 : 
        #print(hex_to_be_trans)
        decimal.append(reduce(lambda x, y: x*16 + y, [int(char, 16) for char in hex_to_be_trans]))
    #print(decimal)

    cmpt = 0
    result = []
    temp = []
    for dec in decimal : 
        temp.append(dec)	
        cmpt = cmpt + 1
        if cmpt%4 == 0 : 
            result.append(temp)
            temp = []
    #print("GROUP BY 4")
    #print(result)
    return result





def RotWord(word):
    return word[1:] + word[0:1]


def SubWord(word):
    return [sbox[byte] for byte in word]


def SubBytes(state):
    return [[sbox[byte] for byte in word] for word in state]


def InvSubBytes(state):
    return [[isbox[byte] for byte in word] for word in state]


def ShiftRows(state):
    Nb = len(state)
    n = [word[:] for word in state]

    for i in range(Nb):
        for j in range(4):
            n[i][j] = state[(i+j) % Nb][j]

    return n


def InvShiftRows(state):
    Nb = len(state)
    n = [word[:] for word in state]

    for i in range(Nb):
        for j in range(4):
            n[i][j] = state[(i-j) % Nb][j]

    return n


def MixColumns(state):
    Nb = len(state)
    n = [word[:] for word in state]

    for i in range(Nb):
        n[i][0] = (gfp2[state[i][0]] ^ gfp3[state[i][1]]
                   ^ state[i][2] ^ state[i][3])
        n[i][1] = (state[i][0] ^ gfp2[state[i][1]]
                   ^ gfp3[state[i][2]] ^ state[i][3])
        n[i][2] = (state[i][0] ^ state[i][1]
                   ^ gfp2[state[i][2]] ^ gfp3[state[i][3]])
        n[i][3] = (gfp3[state[i][0]] ^ state[i][1]
                   ^ state[i][2] ^ gfp2[state[i][3]])

    return n


def InvMixColumns(state):
    Nb = len(state)
    n = [word[:] for word in state]

    for i in range(Nb):
        n[i][0] = (gfp14[state[i][0]] ^ gfp11[state[i][1]]
                   ^ gfp13[state[i][2]] ^ gfp9[state[i][3]])
        n[i][1] = (gfp9[state[i][0]] ^ gfp14[state[i][1]]
                   ^ gfp11[state[i][2]] ^ gfp13[state[i][3]])
        n[i][2] = (gfp13[state[i][0]] ^ gfp9[state[i][1]]
                   ^ gfp14[state[i][2]] ^ gfp11[state[i][3]])
        n[i][3] = (gfp11[state[i][0]] ^ gfp13[state[i][1]]
                   ^ gfp9[state[i][2]] ^ gfp14[state[i][3]])

    return n


def AddRoundKey(state, key):
    Nb = len(state)
    new_state = [[None for j in range(4)] for i in range(Nb)]

    for i, word in enumerate(state):
        for j, byte in enumerate(word):
            new_state[i][j] = byte ^ key[i][j]

    return new_state


def Cipher(block, w, Nb=4, Nk=4, Nr=10):
    state = AddRoundKey(block, w[:Nb])

    for r in range(1, Nr):
        state = SubBytes(state)
        state = ShiftRows(state)
        state = MixColumns(state)
        state = AddRoundKey(state, w[r*Nb:(r+1)*Nb])

    state = SubBytes(state)
    state = ShiftRows(state)
    state = AddRoundKey(state, w[Nr*Nb:(Nr+1)*Nb])

    return state


def InvCipher(block, w, Nb=4, Nk=4, Nr=10):
    state = AddRoundKey(block, w[Nr*Nb:(Nr+1)*Nb])

    for r in range(Nr-1, 0, -1):
        state = InvShiftRows(state)
        state = InvSubBytes(state)
        state = AddRoundKey(state, w[r*Nb:(r+1)*Nb])
        state = InvMixColumns(state)

    state = InvShiftRows(state)
    state = InvSubBytes(state)
    state = AddRoundKey(state, w[:Nb])

    return state


def KeyExpansion(key, Nb=4, Nk=4, Nr=10):
    w = []
    for word in key:
        w.append(word[:])

    i = Nk

    while i < Nb * (Nr + 1):
        temp = w[i-1][:]
        if i % Nk == 0:
            temp = SubWord(RotWord(temp))
            temp[0] ^= Rcon[(i//Nk)]
        elif Nk > 6 and i % Nk == 4:
            temp = SubWord(temp)

        for j in range(len(temp)):
            temp[j] ^= w[i-Nk][j]

        w.append(temp[:])

        i += 1

    return w


def prepare_block(block):
    c = []
    for word in block:
        for byte in word:
            c.append(byte)

    s = None
    for byte in c:
        if sys.version_info[0] == 3:
            if not s:
                s = bytes([byte])
            else:
                s += bytes([byte])
        elif sys.version_info[0] == 2:
            if not s:
                s = chr(byte)
            else:
                s += chr(byte)

    return s


def get_block(inf, Nb=4):
    return process_block(inf[:Nb*4], Nb), inf[Nb*4:]


def padding(inf, Nb=4):
    ''' PKCS#7 padding '''

    # l = len(inf)  # Bytes
    # hl = [int((hex(l*8)[2:]).rjust(16, '0')[i:i+2], 16)
    #       for i in range(0, 16, 2)]

    # l0 = (8 - l) % 16
    # if not l0:
    #     l0 = 16

    # if isinstance(inf, str):  # Python 2
    #     inf += chr(0b10000000)
    #     inf += chr(0)*(l0-1)
    #     for a in hl:
    #         inf += chr(a)
    # elif isinstance(inf, bytes):  # Python 3
    #     inf += bytes([0b10000000])
    #     inf += bytes(l0-1)
    #     inf += bytes(hl)

    padding_length = (Nb*4) - (len(inf) % (Nb*4))

    if padding_length:
        if isinstance(inf, str):  # Python 2
            inf += chr(padding_length) * padding_length
        elif isinstance(inf, bytes):  # Python 3
            inf += bytes([padding_length] * padding_length)

    return inf


def unpadding(inf, Nb=4):
    ''' PKCS#7 padding '''

    padding_length = inf[-1] # python3 mutable version, without ord(inf[-1]) function

    if padding_length < (Nb*4):
        if len(set(inf[-padding_length:])) == 1:
            inf = inf[:-padding_length]

    return inf


def process_block(block, Nb=4):
    if sys.version_info[0] == 3:  # Python 3
        if type(block) == str:
            block = bytes(block, 'utf8')
        pass
    elif sys.version_info[0] == 2:  # Python 2
        block = map(ord, block)

    return [[block[i*4+j] for j in range(4)] for i in range(Nb)]


def process_key(key, Nk=4):
    try:
        key = key.replace(" ", "")
        return [[int(key[i*8+j*2:i*8+j*2+2], 16) for j in range(4)]
                for i in range(Nk)]
    except:
        print ("Password must be hexadecimal.")
        sys.exit()


def print_block(block):
    s = ''

    for i in range(len(block[0])):
        for j in range(len(block)):
            h = hex(block[j][i])[2:]
            if len(h) == 1:
                h = '0'+h
            s += h + ' '
        s += '\n'
    print (s)


def str_block_line(block):
    s = ''

    for i in range(len(block)):
        for j in range(len(block[0])):
            h = hex(block[i][j])[2:]
            if len(h) == 1:
                h = '0'+h
            s += h
    return (s)


def help():
    print ("Help:")
    print("python3 PQAES.py (-demo1|-demo2|-demo3|-demo4|-demo5)")
    print("python3 PQAES.py (-e|-d) <file> [-c (256|512|1024|2048|4096)] [-a (sha256|sha512|sha3_256|sha3_512|blake256)]")
    print("python3 PQAES.py (-e|-d) <file> [-c (256|512|1024|2048|4096)] [-a (sha256|sha512|sha3_256|sha3_512|blake256)] [-k <key_file.key>]")

    print("    -e: Encrypt")
    print("    -d: Decrypt")
    print("    -c <n>: <n> bits key (default 256)")
    print("    -a <alg>: <alg> algorithm of function hashing for PQAES (default sha256)")
    print("    -k <key_file.key>: <key_file.key> file containning the shared key")

    print("Note: a function mode (-e/-d) has to be specified.")
    sys.exit()


def demo1():
    plaintext = "00112233445566778899aabbccddeeff"
    Nb = 4


    # PQAES-256
    print("*"*40)
    print("*" + "PQAES256-SHA256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 8
    Nr = 14

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES256-SHA3-256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 8
    Nr = 14

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES256-BLAKE256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 8
    Nr = 14

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES256-SHA512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 8
    Nr = 14

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES256-SHA3-512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 8
    Nr = 14

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")



def demo2():
    plaintext = "00112233445566778899aabbccddeeff"
    Nb = 4


    # PQAES-512
    print("*"*40)
    print("*" + "PQAES512-SHA256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 16
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES512-SHA3-256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 16
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES512-BLAKE256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 16
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES512-SHA512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 16
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES512-SHA3-512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 16
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


def demo3():
    plaintext = "00112233445566778899aabbccddeeff"
    Nb = 4


    # PQAES-1024
    print("*"*40)
    print("*" + "PQAES1024-SHA256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 32
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES1024-SHA3-256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 32
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES1024-BLAKE256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 32
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES1024-SHA512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 32
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES1024-SHA3-512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 32
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")



def demo4():
    plaintext = "00112233445566778899aabbccddeeff"
    Nb = 4


    # PQAES-2048
    print("*"*40)
    print("*" + "PQAES2048-SHA256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 64
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES2048-SHA3-256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 64
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES2048-BLAKE256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 64
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES2048-SHA512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 64
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES2048-SHA3-512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 64
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")




def demo5():
    plaintext = "00112233445566778899aabbccddeeff"
    Nb = 4


    # PQAES-4096
    print("*"*40)
    print("*" + "PQAES4096-SHA256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 128
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES4096-SHA3-256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 128
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES4096-BLAKE256 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 128
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES4096-SHA512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 128
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")


    print("*"*40)
    print("*" + "PQAES4096-SHA3-512 (Nk=8, Nr=14)".center(38) + "*")
    print("*"*40)
    Nk = 128
    Nr = Nk+6

    key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"
    print("KEY:\t\t{0}".format(key))
    print("KEY LENGTH : "+str(len(key)))

    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    key = process_key(key, Nk)
    expanded_key = pqaes_expand(okm)

    print("PLAINTEXT:\t{0}".format(plaintext))

    block = process_key(plaintext)
    block = Cipher(block, expanded_key, Nb, Nk, Nr)
    print("ENCRYPT:\t{0}".format(str_block_line(block)))

    block = InvCipher(block, expanded_key, Nb, Nk, Nr)
    print("DECRYPT:\t{0}".format(str_block_line(block)))
    print("\n")




def main():

    if len(sys.argv) > 1 and sys.argv[1] == '-demo1':
        demo1()
        sys.exit()

    if len(sys.argv) > 1 and sys.argv[1] == '-demo2':
        demo2()
        sys.exit()

    if len(sys.argv) > 1 and sys.argv[1] == '-demo3':
        demo3()
        sys.exit()

    if len(sys.argv) > 1 and sys.argv[1] == '-demo4':
        demo4()
        sys.exit()

    if len(sys.argv) > 1 and sys.argv[1] == '-demo5':
        demo5()
        sys.exit()

    if len(sys.argv) < 3:
        help()
        sys.exit()
    # python3 PQAES.py (-e|-d) <file> [-c (256|512|1024|2048|4096)] [-a (sha256|sha512|sha3_256|sha3_512|blake256)]
    if len(sys.argv) > 3 and sys.argv[3] != "-c" : 
        help()
        sys.exit()
    
    if (len(sys.argv) > 4) and (sys.argv[4] != "256") and (sys.argv[4] != "512") and (sys.argv[4] != "1024") and (sys.argv[4] != "2048") and (sys.argv[4] != "4096") : 
        help()
        sys.exit()


    if len(sys.argv) > 5 and sys.argv[5] != "-a" : 
        help()
        sys.exit()
    
    if len(sys.argv) > 6 and sys.argv[6] != "sha256" and sys.argv[6] != "sha512" and sys.argv[6] != "sha3_256" and sys.argv[6] != "sha3_512" and sys.argv[6] != "blake256" : 
        help()
        sys.exit()

    mode = sys.argv[1]
    ifile = sys.argv[2]

    if mode not in ['-e', '-d'] or not os.path.exists(ifile):
        help()
        sys.exit()

    try:
        with open(ifile, 'rb') as f:
            inf = f.read()
    except:
        print ("Error while trying to read input file.")
        sys.exit()
    # default parameter 256 bits : 	
    Nb = 4
    Nk = 8
    Nr = 14

    eggs = ''.join(sys.argv[3:5])
    #print("eggs")
    #print(eggs)
    spam = eggs.find('-c')
    if spam > -1 and eggs[spam+2:spam+5] in ['128', '192', '256', '512']:
        Nk = int(eggs[spam+2:spam+6])//32

    if spam > -1 and eggs[spam+2:spam+6] in ['1024', '2048', '4096']:
        Nk = int(eggs[spam+2:spam+6])//32

        
    print("Here Nk : "+str(Nk))	
    Nr = Nk + 6
    # HERE THE CODE FOR ADAPTING THE SHARED KEY
    if len(sys.argv) > 7 and sys.argv[7] == "-k" :
        key_file = sys.argv[8] 
        if os.path.exists(key_file):
            try:
                with open(key_file, 'rb') as f:
                    inf_key = f.read()
            except:
                print ("Error while trying to read input file.")
                sys.exit()
        
        else : 
            print ("Error while trying to read input file.")
            help()
            sys.exit()

        key = binascii.unhexlify(inf_key).hex()
        print("key ")
        print(key)
    
    else :     
        key = raw_input(
            "Enter a key, formed by {0} hexadecimal digits: ".format(Nk * 8))
        key = key.replace(' ', '')

    if len(key) < Nk * 8:
        print ("Key too short. Filling with \'0\',"
               "so the length is exactly {0} digits.".format(Nk * 8))
        key += "0" * (Nk * 8 - len(key))

    elif len(key) > Nk * 8:
        print (
            "Key too long. Keeping only the first {0} digits.".format(Nk * 8))
        key = key[:Nk * 8]
        
    print("key corrected ")
    print(key)
    

    
    # parameter of pq aes
    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    algo = ''.join(sys.argv[5:7])
    #print("algo")
    #print(algo)
    spam = algo.find('-a')
    # all algo : (sha256 | sha512 | sha3_256 | sha3_512 | blake256)	
    # case default 
    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)


    # case algo sha256    
    if spam > -1 and algo[spam+2:spam+8] in ['sha256']:
        okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha512  
    if spam > -1 and algo[spam+2:spam+8] in ['sha512']:
        print("algo : sha512")
        okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha3_256  
    if spam > -1 and algo[spam+2:spam+10] in ['sha3_256']:
        print("algo : sha3_256")
        okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha3_512 
    if spam > -1 and algo[spam+2:spam+10] in ['sha3_512']:
        print("algo : sha3_512")
        okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo blake256
    if spam > -1 and algo[spam+2:spam+10] in ['blake256']:
        print("algo : blake256")
        okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)


    key = process_key(key, Nk)
    # post quantum before analyzing
    
    #print("okm")
    #print(okm)
    expanded_key =  pqaes_expand(okm)

    if mode == '-e':
        ofile = ifile + '.pqaes'
    elif mode == '-d' and (ifile.endswith('.pqaes') or ifile.endswith('.cif')):
        ofile = ifile[:-6]
    else:
        ofile = raw_input('Enter the output filename: ')
        path_end = ifile.rfind('/')
        if path_end == -1:
            path_end = ifile.rfind('\\')
        if path_end != -1:
            ofile = ifile[:path_end+1] + ofile

    if os.path.exists(ofile):
        spam = raw_input(
            'The file "{0}" already exists. Overwrite? [y/n] '.format(ofile))
        if spam.upper() != 'Y':
            ofile = raw_input('Enter new filename: ')

    pb = ProgressBar(len(inf), 0)

    output = None

    if mode == '-e':  # Encrypt
        inf = padding(inf, Nb)

    print('')
    while inf:
        block, inf = get_block(inf, Nb)

        c = pb.update(len(inf))
        if c:
            pb.show()

        if mode == '-e':  # Encrypt
            block = Cipher(block, expanded_key, Nb, Nk, Nr)
        elif mode == '-d':  # Decript
            block = InvCipher(block, expanded_key, Nb, Nk, Nr)

        block = prepare_block(block)
        if output:
            output += block
        else:
            output = block

    if mode == '-d':  # Decript
        output = unpadding(output, Nb)

    with open(ofile, 'wb') as f:
        f.write(output)

    print('')
    sys.exit()

if __name__ == '__main__':
    main()
