#!/usr/bin/env python
# -*- coding: utf-8 -*-

# ---------------------------------------------------
# Copyright (c) 2023 RAKOTONDRAMANANA Sitraka. All Rights Reserved.
# Pablo Caro <s.rakotondra@gmail.com> 
# FO.py
# ---------------------------------------------------

import sys
import os.path
from ProgressBar import ProgressBar
from sibc.csidh import CSIDH, default_parameters
import binascii

if sys.version_info[0] == 3:
    raw_input = input



import hashlib
import hmac
from functools import reduce

hash_len_256 = 32
hash_len_512 = 256



# https://www.geeksforgeeks.org/how-to-add-two-hexadecimal-numbers/

# Python equivalent of above code
 
# Create maps to convert hexadecimal values to decimal and vice versa
hex_value_of_dec = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4,
 '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'A':
 10, 'B': 11, 'C': 12, 'D': 13, 'E': 14, 'F': 15}
dec_value_of_hex = {0: '0', 1: '1', 2: '2', 3: '3', 4: '4',
 5: '5', 6: '6', 7: '7', 8: '8', 9: '9',
 10: 'A', 11: 'B', 12: 'C', 13: 'D', 14: 'E', 15: 'F'}
 
# Function to add the two hexadecimal numbers
def Add_Hex(a, b):
    # Check if length of string first is
    # greater than or equal to string second
    if len(a) < len(b):
        a, b = b, a
    # Store length of both strings
    l1, l2 = len(a), len(b)
    ans = ""
    # Initialize carry as zero
    carry = 0
    i, j = l1 - 1, l2 - 1
    # Traverse till second string
    # get traversal completely
    while j >= 0:
        # Decimal value of element at a[i]
        # Decimal value of element at b[i]
        sum = hex_value_of_dec[a[i]] + hex_value_of_dec[b[j]] + carry
        # Hexadecimal value of sum%16
        # to get addition bit
        addition_bit = dec_value_of_hex[sum % 16]
        # Add addition_bit to answer
        ans += addition_bit
        # Update carry
        carry = sum // 16
        i, j = i - 1, j - 1
    # Traverse remaining element
    # of string a
    while i >= 0:
        # Decimal value of element
        # at a[i]
        sum = hex_value_of_dec[a[i]] + carry
        # Hexadecimal value of sum%16
        # to get addition bit
        addition_bit = dec_value_of_hex[sum % 16]
        # Add addition_bit to answer
        ans += addition_bit
        # Update carry
        carry = sum // 16
        i -= 1
    # Check if still carry remains
    if carry:
        ans += dec_value_of_hex[carry]
    # Reverse the final string
    # for desired output
    ans = ans[::-1]
    # Return the answer
    return ans

def byte_xor(ba1, ba2):
    return bytes([_a ^ _b for _a, _b in zip(ba1, ba2)])

#https://handwiki.org/wiki/HKDF
#sha3_256, sha256, blake2s
###########################################  SHA 256  ##########################################
def hmac_sha256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha256).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_sha256(salt, ikm)

def hkdf_expand_sha256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = "0"
    while len(okm) < length:
        i = Add_Hex(i, "1")
        if len(i)%2 == 1 : 
        	i = "0"+i
        t = hmac_sha256(prk, t + info + binascii.unhexlify(i))
        okm += t
    return okm[:length]

def hkdf_sha256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha256(salt, ikm)
    return hkdf_expand_sha256(prk, info, length)

###########################################  SHA 512  ##########################################

def hmac_sha512(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha512).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha512(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_512)
    return hmac_sha512(salt, ikm)

def hkdf_expand_sha512(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = "0"
    while len(okm) < length:
        i = Add_Hex(i, "1")
        if len(i)%2 == 1 : 
        	i = "0"+i
        t = hmac_sha512(prk, t + info + binascii.unhexlify(i))
        okm += t
    return okm[:length]

def hkdf_sha512(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha512(salt, ikm)
    return hkdf_expand_sha512(prk, info, length)


###########################################  SHA3 256  ##########################################

def hmac_sha3_256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha3_256).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha3_256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_sha3_256(salt, ikm)

def hkdf_expand_sha3_256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = "0"
    while len(okm) < length:
        i = Add_Hex(i, "1")
        if len(i)%2 == 1 : 
        	i = "0"+i
        t = hmac_sha3_256(prk, t + info + binascii.unhexlify(i))
        okm += t
    return okm[:length]

def hkdf_sha3_256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha3_256(salt, ikm)
    return hkdf_expand_sha3_256(prk, info, length)

###########################################  SHA3 512  ##########################################

def hmac_sha3_512(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.sha3_512).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_sha3_512(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_512)
    return hmac_sha3_512(salt, ikm)

def hkdf_expand_sha3_512(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = "0"
    while len(okm) < length:
        i = Add_Hex(i, "1")
        if len(i)%2 == 1 : 
        	i = "0"+i
        t = hmac_sha3_512(prk, t + info + binascii.unhexlify(i))
        okm += t
    return okm[:length]

def hkdf_sha3_512(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_sha3_512(salt, ikm)
    return hkdf_expand_sha3_512(prk, info, length)

###########################################  BLAKE 256  ##########################################

def hmac_blake256(key: bytes, data: bytes):
    return hmac.new(key, data, hashlib.blake2b).digest()
    #h = hashlib.shake_256()
    	
def hkdf_extract_blake256(salt: bytes, ikm: bytes) -> bytes:
    if len(salt) == 0:
        salt = bytes([0] * hash_len_256)
    return hmac_blake256(salt, ikm)

def hkdf_expand_blake256(prk: bytes, info: bytes, length: int) -> bytes:
    t = b""
    okm = b""
    i = "0"
    while len(okm) < length:
        i = Add_Hex(i, "1")
        if len(i)%2 == 1 : 
        	i = "0"+i
        t = hmac_blake256(prk, t + info + binascii.unhexlify(i))
        okm += t
    return okm[:length]


def hkdf_blake256(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    """Key derivation function"""
    prk = hkdf_extract_blake256(salt, ikm)
    return hkdf_expand_blake256(prk, info, length)




def help():
    print ("Help:")
    print("python FO.py -demo")
    print("python FO.py (-e|-d) <file> [-a (sha256|sha512|sha3_256|sha3_512|blake256)] -k <shared_file.key>")
    print("python FO.py (-e|-d) <file> [-a (sha256|sha512|sha3_256|sha3_512|blake256)] -p <pub_file.pub> -s <priv_file.priv>")
    print("    -e: Encrypt")
    print("    -d: Decrypt")
    print("    -a <alg>: <alg> algorithm of function hashing for PQAES (default sha256)")
    print("    -p <pub_file.pub>: public key of emitter/transmitter")
    print("    -s <priv_file.priv>: private key of transmitter/emitter")    
    print("    -k <shared_file.key>: shared key")    
    print("Note: a function mode (-e/-d) has to be specified.")
    sys.exit()

def demo():
    print("demo")
    sys.exit()


def main():

    if len(sys.argv) > 1 and sys.argv[1] == '-demo':
        demo()
        
    if len(sys.argv) < 3:
        help()
    # CONTROL OTHER OPTION 
    if len(sys.argv) > 3 and sys.argv[3] != "-a" : 
        help()
    
    if len(sys.argv) > 4 and sys.argv[4] != "sha256" and sys.argv[4] != "sha512" and sys.argv[4] != "sha3_256" and sys.argv[4] != "sha3_512" and sys.argv[4] != "blake256" : 
        help()


    mode = sys.argv[1]
    ifile = sys.argv[2]

    if mode not in ['-e', '-d'] or not os.path.exists(ifile):
        help()

    try:
        with open(ifile, 'rb') as f:
            inf = f.read()
    except:
        print ("Error while trying to read input file.")
        sys.exit()

    # EXCHANGE PROTOCOL DH, EDCH, CSIDH
    key = "123456789A"
    # BEGIN CODE SHARED KEY
    if len(sys.argv) > 5 and (sys.argv[5] == "-p") : 
        bool_shared_key = False
        #print("traiting public key")
        pub_file = sys.argv[6]
        if os.path.exists(pub_file) != True : 
            help()
        try:
            with open(pub_file, 'rb') as f:
                inf1 = f.read()

        except:
            print ("Error while trying to read input file.")
            sys.exit()
            
        #print("pub_key")
        #https://stackoverflow.com/questions/6624453/whats-the-correct-way-to-convert-bytes-to-a-hex-string-in-python-3
        public_key = binascii.unhexlify(inf1)
 
    else :
        if len(sys.argv) > 5 and sys.argv[5] != "-k" :
            help()
 
 
    if len(sys.argv) > 5 and (sys.argv[5] == "-k") :
        bool_shared_key = True        
    elif len(sys.argv) > 7 and sys.argv[7] == "-s" : 
        bool_shared_key = False
        #print("traiting private key")
        priv_file = sys.argv[8]
        if os.path.exists(priv_file) != True : 
            help()
        try:
            with open(priv_file, 'rb') as f:
                inf2 = f.read()

        except:
            print ("Error while trying to read input file.")
            sys.exit()
            
        #print("pub_key")
        #https://stackoverflow.com/questions/6624453/whats-the-correct-way-to-convert-bytes-to-a-hex-string-in-python-3
        secret_key = binascii.unhexlify(inf2)
 
    else :
        help()
 
    if bool_shared_key : 
        shared_file = sys.argv[6]
        if os.path.exists(shared_file) != True : 
            help()
        try:
            with open(shared_file, 'rb') as f:
                inf4 = f.read()
        except:
            print ("Error while trying to read input file.")
            sys.exit()
        shared_secret = binascii.unhexlify(inf4)
        print("shared key")
        print(shared_secret.hex())	
        key = shared_secret.hex()	
                     
    else :
        csidh = CSIDH(**default_parameters)
        shared_secret = csidh.dh(secret_key, public_key)
        print("shared key")
        print(shared_secret.hex())	
        key = shared_secret.hex()	
        # save shared key
        with open("shared.key", 'wb') as f:
            f.write(str(key).encode())
    
    # END CODE SHARED KEY

    if mode == '-e':
        ofile = ifile + '.fo'
    elif mode == '-d' and (ifile.endswith('.fo') or ifile.endswith('.cif')):
        ofile = ifile[:-3]
    else:
        ofile = raw_input('Enter the output filename: ')
        path_end = ifile.rfind('/')
        if path_end == -1:
            path_end = ifile.rfind('\\')
        if path_end != -1:
            ofile = ifile[:path_end+1] + ofile

    if os.path.exists(ofile):
        spam = raw_input(
            'The file "{0}" already exists. Overwrite? [y/n] '.format(ofile))
        if spam.upper() != 'Y':
            ofile = raw_input('Enter new filename: ')

    pb = ProgressBar(len(inf), 0)

    output = None
        
    if mode == '-e':  # Encrypt	
        # adding test for generating hkdf and xor with file
        algo = ''.join(sys.argv[3:5])
        #print("algo")
        #print(algo)
        
        spam = algo.find('-a')
        # all algo : (sha256 | sha512 | sha3_256 | sha3_512 | blake256)	
        # case default 
        #print("len infile")
        #print(len(inf))
        
        # parameter of pq aes
        salt_param = '000102030405060708090a0b0c'
        key_param = key
        info_param = 'f0f1f2f3f4f5f6f7f8f9'
        length_param = len(inf)

        okm = hkdf_sha256(salt=bytes.fromhex(salt_param), ikm = bytes.fromhex(key_param), info=bytes.fromhex(info_param), length=length_param)
        output = byte_xor(okm, inf)
        hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
        output = hash_fo + output


        # case algo sha256    
        if spam > -1 and algo[spam+2:spam+8] in ['sha256']:
            print("algo : sha256")
            okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param), info=bytes.fromhex(info_param), length=length_param)
            output = byte_xor(okm, inf)
            #print("output")
            #print(output)
            hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
            output = hash_fo + output
            #print("output2")
            #print(output)
            #len_hash_info = len(hash_fo)
            #output3 = output[len_hash_info:]
            #print("output3")
            #print(output3)

        # case algo sha512  
        if spam > -1 and algo[spam+2:spam+8] in ['sha512']:
            print("algo : sha512")
            okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
               length=length_param)
            output = byte_xor(okm, inf)              
            hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
            output = hash_fo + output


        # case algo sha3_256  
        if spam > -1 and algo[spam+2:spam+10] in ['sha3_256']:
            print("algo : sha3_256")
            okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)
            output = byte_xor(okm, inf)
            hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
            output = hash_fo + output

        
        # case algo sha3_512 
        if spam > -1 and algo[spam+2:spam+10] in ['sha3_512']:
            print("algo : sha3_512")
            okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
               length=length_param)
            output = byte_xor(okm, inf)
            hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
            output = hash_fo + output

        # case algo blake256
        if spam > -1 and algo[spam+2:spam+10] in ['blake256']:
            print("algo : blake256")
            okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
                ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
                   length=length_param) 
            output = byte_xor(okm, inf)    
            hash_fo = hmac_sha256(bytes.fromhex(key_param), output)
            output = hash_fo + output

    elif mode == '-d':  # Decript
        # adding test for generating hkdf and xor with file
        algo = ''.join(sys.argv[3:5])
        # print("algo")
        # print(algo)
        
        spam = algo.find('-a')
        # all algo : (sha256 | sha512 | sha3_256 | sha3_512 | blake256)	
        # case default 
        # print("len infile")
        # print(len(inf))
        
        # parameter of pq aes
        salt_param = '000102030405060708090a0b0c'
        key_param = key
        info_param = 'f0f1f2f3f4f5f6f7f8f9'
        length_param = len(inf)

        okm = hkdf_sha256(salt=bytes.fromhex(salt_param), ikm = bytes.fromhex(key_param), info=bytes.fromhex(info_param), length=length_param)

        # case algo sha256    
        if spam > -1 and algo[spam+2:spam+8] in ['sha256']:
            print("algo : sha256")
            okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param), info=bytes.fromhex(info_param), length=length_param)
            
            hash_fo_len = len(hmac_sha256(bytes.fromhex(key_param), b""))
            
            if len(inf) >= hash_fo_len : 
                hash_fo_verify =inf[0:hash_fo_len] 
                inf = inf[hash_fo_len:]
                hash_fo = hmac_sha256(bytes.fromhex(key_param), inf)
                output = byte_xor(okm, inf)
                #print("inf")
                #print(inf)
                #print("hash_fo_verify")
                #print(hash_fo_verify)
                #print("hash_fo")
                #print(hash_fo)
                
                if( hash_fo_verify == hash_fo):
                    print("HASH VERIFICATION OK")
                else :
                    print("HASH VERIFICATION ERROR")
                    output = b"HASH VERIFICATION ERROR"
            
            else : 
                print("HASH VERIFICATION ERROR")
                output = b"HASH VERIFICATION ERROR"

            

        # case algo sha512  
        if spam > -1 and algo[spam+2:spam+8] in ['sha512']:
            print("algo : sha512")
            okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
               length=length_param)

            hash_fo_len = len(hmac_sha256(bytes.fromhex(key_param), b""))
            
            if len(inf) >= hash_fo_len : 
                hash_fo_verify =inf[0:hash_fo_len] 
                inf = inf[hash_fo_len:]
                hash_fo = hmac_sha256(bytes.fromhex(key_param), inf)
                output = byte_xor(okm, inf)
                
                if( hash_fo_verify == hash_fo):
                    print("HASH VERIFICATION OK")
                else :
                    print("HASH VERIFICATION ERROR")
                    output = b"HASH VERIFICATION ERROR"
            
            else : 
                print("HASH VERIFICATION ERROR")
                output = b"HASH VERIFICATION ERROR"


        # case algo sha3_256  
        if spam > -1 and algo[spam+2:spam+10] in ['sha3_256']:
            print("algo : sha3_256")
            okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

            hash_fo_len = len(hmac_sha256(bytes.fromhex(key_param), b""))
            
            if len(inf) >= hash_fo_len : 
                hash_fo_verify =inf[0:hash_fo_len] 
                inf = inf[hash_fo_len:]
                hash_fo = hmac_sha256(bytes.fromhex(key_param), inf)
                output = byte_xor(okm, inf)
                
                if( hash_fo_verify == hash_fo):
                    print("HASH VERIFICATION OK")
                else :
                    print("HASH VERIFICATION ERROR")
                    output = b"HASH VERIFICATION ERROR"
            
            else : 
                print("HASH VERIFICATION ERROR")
                output = b"HASH VERIFICATION ERROR"

        
        # case algo sha3_512 
        if spam > -1 and algo[spam+2:spam+10] in ['sha3_512']:
            print("algo : sha3_512")
            okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
            ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
               length=length_param)

            hash_fo_len = len(hmac_sha256(bytes.fromhex(key_param), b""))
            
            if len(inf) >= hash_fo_len : 
                hash_fo_verify =inf[0:hash_fo_len] 
                inf = inf[hash_fo_len:]
                hash_fo = hmac_sha256(bytes.fromhex(key_param), inf)
                output = byte_xor(okm, inf)
                
                if( hash_fo_verify == hash_fo):
                    print("HASH VERIFICATION OK")
                else :
                    print("HASH VERIFICATION ERROR")
                    output = b"HASH VERIFICATION ERROR"
            
            else : 
                print("HASH VERIFICATION ERROR")
                output = b"HASH VERIFICATION ERROR"

        # case algo blake256
        if spam > -1 and algo[spam+2:spam+10] in ['blake256']:
            print("algo : blake256")
            okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
                ikm = bytes.fromhex(key_param),
               info=bytes.fromhex(info_param),
                   length=length_param)     
            hash_fo_len = len(hmac_sha256(bytes.fromhex(key_param), b""))
            
            if len(inf) >= hash_fo_len : 
                hash_fo_verify =inf[0:hash_fo_len] 
                inf = inf[hash_fo_len:]
                hash_fo = hmac_sha256(bytes.fromhex(key_param), inf)
                output = byte_xor(okm, inf)
                
                if( hash_fo_verify == hash_fo):
                    print("HASH VERIFICATION OK")
                else :
                    print("HASH VERIFICATION ERROR")
                    output = b"HASH VERIFICATION ERROR"
            
            else : 
                print("HASH VERIFICATION ERROR")
                output = b"HASH VERIFICATION ERROR"
            

    with open(ofile, 'wb') as f:
        f.write(output)

    print('')
    sys.exit()

if __name__ == '__main__':
    main()
