    # parameter of pq aes
    salt_param = '000102030405060708090a0b0c'
    key_param = key
    info_param = 'f0f1f2f3f4f5f6f7f8f9'
    length_param = 16*(Nr+1)

    algo = ''.join(sys.argv[5:7])
    #print("algo")
    #print(algo)
    spam = algo.find('-a')
    # all algo : (sha256 | sha512 | sha3_256 | sha3_512 | blake256)	
    # case default 
    okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
    ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)


    # case algo sha256    
    if spam > -1 and algo[spam+2:spam+8] in ['sha256']:
        okm = hkdf_sha256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha512  
    if spam > -1 and algo[spam+2:spam+8] in ['sha512']:
        print("algo : sha512")
        okm = hkdf_sha512(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha3_256  
    if spam > -1 and algo[spam+2:spam+10] in ['sha3_256']:
        print("algo : sha3_256")
        okm = hkdf_sha3_256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo sha3_512 
    if spam > -1 and algo[spam+2:spam+10] in ['sha3_512']:
        print("algo : sha3_512")
        okm = hkdf_sha3_512(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

    # case algo blake256
    if spam > -1 and algo[spam+2:spam+10] in ['blake256']:
        print("algo : blake256")
        okm = hkdf_blake256(salt=bytes.fromhex(salt_param),
        ikm = bytes.fromhex(key_param),
           info=bytes.fromhex(info_param),
           length=length_param)

